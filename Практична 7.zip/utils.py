import random
import os
import json
import re  # імпортуємо модуль re для регулярних виразів

# Шлях до папки з картками Elder_Futhark
cards_folder = 'C:/Games/Python/Runariumbot/Elder_Futhark'

def get_random_card():
    files = [f for f in os.listdir(cards_folder) if f.endswith('.json') and os.path.isfile(os.path.join(cards_folder, f))]
    if not files:  # Перевірка, чи є файли в папці
        raise FileNotFoundError("No JSON files found in the cards folder.")
    
    random_file = random.choice(files)
    with open(os.path.join(cards_folder, random_file), 'r', encoding='utf-8') as f:
        card = json.load(f)
    return card

def extract_keywords(meaning):
    clean_meaning = re.sub(r"[^\w\s]", "", meaning)  # Видаляємо всі символи, що не є буквами або пробілами
    words = clean_meaning.lower().split()  # Розбиваємо текст на слова
    ignore_words = {"руна", "символізує"}  # Слова, які потрібно ігнорувати
    keywords = [word for word in words if word not in ignore_words]  # Фільтруємо слова
    return keywords
