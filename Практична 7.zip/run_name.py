import telebot
import random
import json
from utils import get_random_card

def run_name_quiz(bot, message):
    card = get_random_card()
    rune = card['rune']
    correct_answers = [card['name'], card['Lat.name'], card['Run.name']]
    
    bot.send_message(message.chat.id, f"{rune} - як називається ця руна?")
    bot.register_next_step_handler(message, check_answer, correct_answers, bot)

def check_answer(message, correct_answers, bot):
    user_answer = message.text.strip()
    if user_answer in correct_answers:
        bot.send_message(message.chat.id, "ви вгадали")
    else:
        bot.send_message(message.chat.id, "ви помилились")

