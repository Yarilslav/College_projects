import telebot
import random
import json
from utils import get_random_card, extract_keywords

def run_meaning_quiz(bot, message):
    card = get_random_card()  
    rune = card['rune']
    meaning = card['meaning']
    
    bot.send_message(message.chat.id, f"{rune} - що символізує ця руна?")
    bot.register_next_step_handler(message, check_meaning_answer, meaning, bot)

def check_meaning_answer(message, correct_meaning, bot):
    user_answer = message.text.strip().lower()
    keywords = extract_keywords(correct_meaning)
    
    if any(keyword in user_answer for keyword in keywords):
        bot.send_message(message.chat.id, "ви вгадали")
    else:
        correct_answers = ', '.join(keywords)
        bot.send_message(message.chat.id, f"ви помилились. Правильні відповіді: {correct_answers}")
