import telebot

def send_elder_futhark(bot, message):
    bot.send_message(message.chat.id, 'Руни старшого футарку для копіювання: \n\n ᚠ ᚢ ᚦ ᚨ ᚱ ᚲ  ᚷ ᚹ     ᚺ ᚾ ᛁ ᛃ ᛇ ᛈ ᛉ ᛋ      ᛏ ᛒ ᛖ ᛗ ᛚ ᛜ ᛝ ᛞ')
