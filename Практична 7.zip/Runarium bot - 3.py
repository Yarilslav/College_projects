import os
import telebot
from dotenv import load_dotenv

from get_elder_futhark import send_elder_futhark
from run_name import run_name_quiz
from name_run import run_quiz
from run_meaning import run_meaning_quiz

load_dotenv()  
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
bot = telebot.TeleBot(TOKEN)


#------Декоратор----------------------------------------------------

def decorator(func):
    def wrapper(*args, **kwargs):
        print(f"Виконується функція: {func.__name__}")
        result = func(*args, **kwargs)
        print(f"Функція {func.__name__} виконана")
        return result
    return wrapper
    
#-------------------------------------------------------------------


# Обробник команди /start
@bot.message_handler(commands=['start'])
@decorator
def send_welcome(message):
    bot.send_message(message.chat.id, "Вітаю! Я бот Рунарій, створений для того щоб допомогти вам в запам'ятовуванні рун. \n\n Щоб дізнатись необхіну інформацію використайте команду /info. \n\n Також майте на увазі що у мене немає серверів які б підримували мене в робочому стані, тому якщо ви хочете скористатись мною - напишіть моєму творцю @Yokoshimaslav")


# Обробник команди /info
@bot.message_handler(commands=['info'])
@decorator
def send_welcome(message):
    bot.send_message(message.chat.id, ' При використані бота майте на увазі що він ще на дуже "сирих" стадіях, і функціонує досить обмежено і незручно. \n\n Поки що в бота є три режими: \n 1) /Run_Name - бот дає вам руну, а ви маєте написати її назву. \n 2) /Name_Run - бот дає вам назву руни, а ви повинні відправити відповідний символ. \n 3) /Run_Meaning - бот дає вам руну, а ви повинні написати її значення (наприклад: Захист, Дар, тощо). \n\n також бот може видати вам набір символів, якщо потрібно (/get_elder_futhark). \n\n Якщо є якісь пропозиції, зауваження, тощо - пишіть @Yokoshimaslav')

@bot.message_handler(commands=['get_elder_futhark'])
@decorator
def elder_futhark(message):
    send_elder_futhark(bot, message)

@bot.message_handler(commands=['Run_Name'])
@decorator
def run_name(message):
    run_name_quiz(bot, message)

@bot.message_handler(commands=['Name_Run'])
@decorator
def name_run(message):
    run_quiz(bot, message)

@bot.message_handler(commands=['Run_Meaning'])
@decorator
def run_meaning(message):
    run_meaning_quiz(bot, message)



#точка входу ---------------------------
def main():
    bot.polling(none_stop=True)

# Перевірка, чи запущено безпосередньо ----------------
if __name__ == '__main__':
    main()

#--------------------------------------------------

#Пояснення:
#Функція main() — це основна точка входу, яка відповідає за запуск бота.
#if __name__ == '__main__': — цей блок гарантує, що функція main() буде викликана тільки тоді, коли цей скрипт запускається безпосередньо (а не імпортується як модуль).